/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.ArrayList;

/**
 *
 * @author curso
 */
public class Path {
    
    ArrayList <Integer> path = new ArrayList();
    int totalWeight = 0;
    int offset = 0;

    public ArrayList<Integer> getPath() {
        return path;
    }

    public void setPath(ArrayList<Integer> path) {
        this.path = path;
    }

    public int getTotalWeight() {
        return totalWeight;
    }

    public void setTotalWeight(int totalWeight) {
        this.totalWeight = totalWeight;
    }

    public int getOffset() {
        return offset;
    }

    public void setOffset(int offfset) {
        this.offset = offfset;
    }
    
    
}
